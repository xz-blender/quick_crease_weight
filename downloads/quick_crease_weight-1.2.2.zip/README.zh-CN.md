<div align="center">

<img src="docs/media/icon.png" alt="Quick Crease Weight — 网格顶点、橙色折痕边与蓝色倒角权重边" width="88" height="88">

# Quick Crease Weight

**两组快捷键，让折痕与倒角权重跟上建模节奏。**

在 Blender 网格编辑模式中，根据点 / 边选择模式自动选择属性，拖动鼠标即可调整。

[![Blender](https://img.shields.io/badge/Blender-4.2%2B-E87D0D?style=flat-square&logo=blender&logoColor=white)](#兼容性)
[![Version](https://img.shields.io/badge/version-1.2.2-38BDF8?style=flat-square)](CHANGELOG.md)
[![License](https://img.shields.io/badge/license-GPL--3.0--or--later-7C83FD?style=flat-square)](LICENSE)
[![Dependencies](https://img.shields.io/badge/dependencies-none-34D399?style=flat-square)](#功能一览)

**[下载插件 ZIP](https://github.com/xz-blender/quick_crease_weight/raw/refs/heads/main/downloads/quick_crease_weight-1.2.2.zip)** · [快速开始](#快速开始) · [自定义设置](#自定义设置) · [English](README.md)

<img src="docs/media/cover.jpg" alt="Quick Crease Weight 封面：橙色折痕、蓝色倒角权重" width="100%">

<sub>橙色折痕 · 蓝色倒角权重 · 为网格编辑模式设计。</sub>

</div>

## 功能一览

| 功能 | 使用体验 |
| --- | --- |
| **自动识别点 / 边** | 点模式调整顶点属性，边和面模式调整边属性，无需切换工具。 |
| **折痕 + 倒角权重** | 默认 <kbd>Shift</kbd> + <kbd>E</kbd> 和 <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>E</kbd>。 |
| **独立主题色** | 折痕默认为橙色，倒角权重默认为蓝色，两种颜色均可分别设置。 |
| **实时 HUD** | 圆角数值卡片、选择标签与胶囊进度条；按键提示独立放在右侧，操作期间持续显示。 |
| **快捷键与外观可定制** | 原生键位编辑器，配合位置、字号、颜色和背景透明度设置。 |
| **可取消、可撤销** | 取消恢复每个元素的原值；确认后使用 Blender 撤销。 |
| **多物体编辑** | 同时调整多个编辑中的网格，共享网格只处理一次。 |
| **高效更新** | 缓存 HUD 图形与布局，仅在应用值变化时重写网格。 |
| **中英文自动切换** | 随 Blender 界面语言显示英文或简体中文，HUD 和状态栏同步更新。 |
| **独立运行** | 无第三方 Python 依赖，安装后即可使用。 |

## 操作演示

<img src="docs/media/demo.gif" alt="Blender 实录：Shift E 调整顶点折痕，Ctrl Shift E 调整边倒角权重，Ctrl 和 Alt 快速设为 1 与 0" width="100%">

使用 **Blender 4.5.4** 和真实插件英文界面录制。细分曲面与倒角修改器用于展示权重效果。[观看或下载 MP4](docs/media/demo.mp4)。

## 快速开始

1. **安装插件**：下载上方 ZIP，在 Blender 的 **编辑 → 偏好设置 → 插件** 菜单中选择 **从磁盘安装 / Install from Disk**，选择 ZIP 并启用 **Quick Crease Weight**。
2. **选择元素**：进入网格编辑模式，切换到点或边选择，选中要调整的元素。
3. **调用并调整**：按 <kbd>Shift</kbd> + <kbd>E</kbd> 设置折痕，或 <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>E</kbd> 设置倒角权重；左右移动鼠标，左键确认。

> [!TIP]
> 请使用上方的**插件 ZIP**。它已经过 Blender 扩展校验，并排除了文档配图和测试文件；GitHub 的 **Code → Download ZIP** 是开发源码包。

### 操作速查

| 输入 | 操作 |
| --- | --- |
| <kbd>Shift</kbd> + <kbd>E</kbd> | 开始调整折痕 |
| <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>E</kbd> | 开始调整倒角权重 |
| 鼠标左右移动 | 在 **0–1** 范围内连续调整 |
| 按住 <kbd>Shift</kbd> | 按 **0.1** 吸附 |
| 按下 <kbd>Ctrl</kbd> / <kbd>Alt</kbd> | 设置为 **1** / **0** |
| 左键 / <kbd>Enter</kbd> | 确认 |
| 右键 / <kbd>Esc</kbd> | 取消并恢复原值 |
| 中键 / 滚轮 | 旋转 / 缩放视图 |

调用后先松开快捷键中的修饰键，再重新按下以使用上述控制，避免启动倒角权重工具时意外将数值设为 1。

初始显示值是所选元素的**平均值**；开始拖动后，所选元素会被设置为同一个值。仅调用后直接确认不会改写原值。

**界面语言：**在 Blender **偏好设置 → 界面 → 翻译** 中选择英文或简体中文，插件的 HUD、工具名称、偏好设置、状态栏和警告会自动跟随，也支持“自动”使用系统语言。切换后无需重新启用插件。界面、工具提示和报告分别遵循 Blender 对应的翻译开关；未提供译文的文本回退英文。

## 自定义设置

打开 **偏好设置 → 插件 → Quick Crease Weight**。

| 设置 | 可调整内容 |
| --- | --- |
| 快捷键 | 两个工具的按键、修饰键及启用状态 |
| 操作手感 | 鼠标灵敏度 |
| HUD 布局 | 底部居中、顶部居中、跟随鼠标，水平 / 垂直偏移 |
| HUD 外观 | 字号、文字颜色、折痕主题色、倒角权重主题色、背景颜色与透明度、圆角半径、卡片阴影、文字阴影 |
| 信息显示 | HUD 总开关、右侧按键列表、数值进度条 |

鼠标和键盘操作提示全部放在 HUD 右侧的独立悬浮列表中，不占用数值卡片。两块面板共用外观设置、一起定位，并在窄视口中自动缩放。可在偏好设置中关闭 **显示右侧按键列表**。

<p align="center">
  <img src="docs/images/bevel-hud.png" alt="蓝色大字号 HUD 位于视口顶部，显示边倒角权重 0.70" width="100%">
  <br><sub>顶部定位与大字号示例：倒角权重使用默认蓝色主题。</sub>
</p>

<details>
<summary><strong>查看偏好设置界面</strong></summary>

<img src="docs/images/preferences.png" alt="键位编辑器、鼠标灵敏度和 HUD 样式设置" width="100%">

截图来自独立测试窗口中的实际偏好设置布局；折痕快捷键已演示性地改为 **Shift + Q**，安装后的默认值仍为 **Shift + E**。

</details>

设置随 Blender 偏好设置保存。未开启自动保存时，请点击 **保存偏好设置**。

## 选择模式与属性

| 选择模式 | 折痕属性 | 倒角权重属性 |
| --- | --- | --- |
| 点 | `crease_vert` | `bevel_weight_vert` |
| 边 / 面 | `crease_edge` | `bevel_weight_edge` |

混合选择模式中，**点模式优先**。工具只处理可见且选中的元素，取消时还会移除本次新建的属性层。

## 常见问题

<details>
<summary><strong>已写入倒角权重，为什么没有看到倒角效果？</strong></summary>

本插件负责写入权重。需要添加倒角修改器，将限制方式设为 **权重 / Weight**，并选择与顶点或边属性对应的影响模式。折痕效果则通常配合细分曲面修改器查看。

</details>

<details>
<summary><strong>所选元素原来有不同数值，取消能完整恢复吗？</strong></summary>

可以。工具保存每个选中元素的原值；右键或 Esc 会分别恢复它们，包括多物体编辑中的各个网格。

</details>

## 性能

本机 Blender 4.5.4 中，使用同一基准脚本与 v1.1.2 对比：

| 场景 | 优化前 | v1.2.0 |
| --- | ---: | ---: |
| HUD 静止 / 跟随鼠标，CPU 提交耗时中位数 | 约 1.29 ms | 约 0.09 ms |
| HUD 数值变化，CPU 提交耗时中位数 | 1.29 ms | 0.20 ms |
| 200,344 条选中边，每次变值写入耗时中位数 | 8.18–8.36 ms | 3.82–3.83 ms |
| 连续 20 次相同值触发的网格更新次数 | 20 | 0 |

以上测量插件自身的工作耗时，不代表整个视口的帧耗时。首次写入会建立元素缓存，后续写入复用缓存。完整数据与测量方法见 [性能记录](docs/PERFORMANCE.md)。

## 兼容性

最低声明版本：**Blender 4.2**。以下是本机实际验证记录，不代表所有系统和版本组合都已测试。

| 版本 | 集成检查 | 窗口交互检查 |
| --- | --- | --- |
| 4.3.2 | 14 项通过 | 12 项翻译场景通过，包括操作中切换语言及窄视口布局 |
| 4.5.4 LTS | 14 项通过 | 12 项翻译场景通过；快捷键、改键、取消、撤销、HUD、偏好设置通过 |
| 5.2.0 LTS Beta 本机构建 | 14 项通过 | 12 项翻译场景通过，包括操作中切换语言及窄视口布局 |
| 5.3.0 Alpha 本机构建 | 翻译更新前 13 项通过 | — |
| 4.2.0 | 14 项通过 | 尚未实测 |

<details>
<summary><strong>开发、验证与打包</strong></summary>

在项目目录运行以下 PowerShell 命令，并将 `$blender` 改为本机 Blender 路径：

```powershell
$blender = 'C:\path\to\blender.exe'

# 使用真实 Blender 数据检查属性写入、还原、多物体编辑与注册。
& $blender --background --factory-startup --python-exit-code 1 --python tests/blender_integration.py

# 校验并构建安装包。
& $blender --factory-startup --command extension validate
New-Item -ItemType Directory -Path dist -Force | Out-Null
& $blender --factory-startup --command extension build --output-dir dist
& $blender --factory-startup --command extension validate dist/quick_crease_weight-1.2.2.zip
```

界面测试：

```powershell
& $blender --factory-startup --enable-event-simulate --python tests/blender_ui_smoke.py
& $blender --factory-startup --enable-event-simulate -p 60 60 900 900 --python tests/blender_translation.py
```

界面测试在工厂设置窗口中运行，不保存用户偏好设置，结束后自动关闭。结果位于 `tests/artifacts/`。翻译测试覆盖操作中切换语言、独立翻译开关、错误提示、重新启用以及 HUD 文字边界。

| 文件 | 职责 |
| --- | --- |
| `mesh_data.py` | 选择快照、属性写入与取消还原 |
| `operators.py` | 交互操作、确认与清理 |
| `hud.py` | 视口绘制 |
| `translation.py` | 中英文词典、原生翻译注册与动态文本入口 |
| `preferences.py` / `keymaps.py` | 偏好设置与键位注册 |

</details>

## 作者与许可

默认 **Shift + E** 会在网格编辑模式中优先调用本扩展，与 Blender 内置折痕快捷键重叠。可在扩展偏好设置中改键或禁用该绑定；停用扩展会移除其快捷键。界面支持跟随 Blender 自动切换英文和简体中文。扩展离线运行，不收集遥测，不需要账号、其他扩展或第三方依赖。

图标、封面和演示文件已整理为 [媒体素材包](docs/media/README.md)，包含 Blender 官方扩展平台使用的英文演示素材。

作者：**WXZ**。

采用 **GPL-3.0-or-later**：可按 GNU GPL 第 3 版或任何后续版本使用、修改和分发。完整第 3 版文本见 [LICENSE](LICENSE)。
